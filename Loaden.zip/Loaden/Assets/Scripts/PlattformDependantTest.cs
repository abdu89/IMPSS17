﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlattformDependantTest : MonoBehaviour {


	#if UNITY_EDITOR
	// Use this for initialization
	void Start () {
		Debug.Log ("We are inside editor");

	#else
	Debug.Log ("We are inside adnroid");
	#endif
	}
	// Update is called once per frame
	void Update () {

		#if UNITY_EDITOR
		//Input im Editor verarbeiten
		if(Input.GetButtonDown("Jump")){
			doJump();
		}

		#else
		if (Input.touchCount > 0) {	
			//Touch input available
			for(int i = 0; i<Input.touchCount; i++){
				Touch touch = Input.GetTouch(i);
				if(Touch.deltaTime > 1f){
				doJump();
				}
				Debug.Log (touch.position);

		}
	}

		#endif
	}

			private void doJump(){
			Debug.Log ("jump");
			Vector3 oldPosition = transform.position;
			transform.position = new Vector3(oldPosition.x, oldPosition.y+1, oldPosition.z);
 	}
}
